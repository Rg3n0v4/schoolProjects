package com.example.project_1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.TextView;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class SecondActivity extends AppCompatActivity {

    //sets up EditText and TextView used .xml file
    EditText phoneNum;
    TextView phoneInstTxt;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        //connects the EditText and TextView from the .xml file to being present in the .java file
        phoneNum = (EditText) findViewById(R.id.phoneNum);
        phoneInstTxt = (TextView) findViewById(R.id.phoneInstTxt);

        //sets up the phoneNum EditText
        phoneNum.setOnEditorActionListener(new EditText.OnEditorActionListener()
        {
            @Override
            public boolean onEditorAction(TextView textView, int i, KeyEvent keyEvent)
            {
                //sets up proper US phone number format
                Pattern phoneFormat = Pattern.compile("(^|(\\+)?1|(\\+)?\\(1\\))(\\s)?\\(?([0-9]{3})\\)?[-.\\s]?([0-9]{3})[-.\\s]?([0-9]{4})$");
                Matcher phoneInput = phoneFormat.matcher(phoneNum.getText());

                //if the enter or green check mark button on the soft keyboard is pressed
                // then check if it matches the proper format for a US phone number
                if(i == EditorInfo.IME_ACTION_DONE)
                {
                    //checks if phoneInput is in the valid format
                    if (phoneInput.matches())
                    {
                        //returns back to the MainActivity that the phone number is valid
                        Intent intent = new Intent();
                        intent.putExtra("return", phoneNum.getText().toString()); //<-sends back the phone number that user put in with the label "return"
                        if(intent.hasExtra("return"))
                        {
                            setResult(RESULT_OK, intent); //sets intent to be OK
                        }
                        //Log.e("INFO", "Result ok");
                        finish(); //SecondActivity closes itself
                    }
                    else
                    {
                        //returns back to the MainActivity that the phone number is invalid
                        Intent intent = new Intent();
                        intent.putExtra("return", phoneNum.getText().toString()); //<-sends back the phone number that user put in with the label "return"
                        setResult(RESULT_CANCELED, intent); //sets intent to be CANCELED
                        //Log.e("INFO", "Result cancelled");
                        finish(); //SecondActivity closes itself
                    }
                }
                return false;
            }

        });
    }

}
