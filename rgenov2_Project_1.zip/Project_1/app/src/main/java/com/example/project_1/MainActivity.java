package com.example.project_1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;


public class MainActivity extends AppCompatActivity {

    //sets up Button and TextView from the .xml file to this .java file
    Button startSecond;
    TextView welcomeTxt;
    Button showDial;

    //global variable that is set depending on if the number the user input was valid
    private int numberValid = 1; //initialized to 1, -1 for OK, 0 for CANCELED

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //connects the Button in .java file to the one in the .xml
        startSecond = (Button) findViewById(R.id.startSecond);
        showDial = (Button) findViewById(R.id.showDial);
        showDial.setEnabled(false); //disables the showDial button because the user hasn't gone to the SecondActivity

        //sets up onClick for startSecond to start the second activity
        startSecond.setOnClickListener(new View.OnClickListener(){
            //if the button is clicked then it should go to SecondActivity.java
            @Override
            public void onClick(View view) {
                startSecondActivity();
            }
        });

        //sets up onClick for showDial to open and show dialer
        showDial.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                openDialer();
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        //connects the TextView in the .java file to the one in the .xml
        welcomeTxt = (TextView) findViewById(R.id.welcomeTxt);

        String resultString;

        //checks if the requestCode returned back with an OK result
        if(requestCode == 0)
        {
            //try-catch block deals with case of user hitting the back button from being on the
            // second activity back to the main activity
            try{
                if(data.hasExtra("return"))//checks if the label "return" has something from SecondActivity
                {
                    resultString = data.getStringExtra("return");//<-sends back the phone number that user put in with the label "return"

                    if(resultString.equals("")) //checks if the resultString is empty
                    {
                        welcomeTxt.setText("No input given"); //since the string is empty from SecondActivity to be displayed on the MainActivity
                    }
                    else
                    {
                        welcomeTxt.setText(resultString); //sets the returned string from SecondActivity to be displayed on the MainActivity
                    }
                }
            }catch(Exception e){}

            //checks if the resultCode from the SecondActivity returned OK or CANCELED
            if(resultCode == RESULT_OK)
            {
                numberValid = -1; //set to -1 letting the dialer know if the number was valid
                showDial.setEnabled(true); //enables the showDial button because the user has been able to go the SecondActivity
                //Log.e("INFO", "Result ok");
            }
            else if(resultCode == RESULT_CANCELED)
            {
                numberValid = 0; //set to 0 letting the dialer know if the number was invalid
                showDial.setEnabled(true); //enables the showDial button because the user has been able to go the SecondActivity
                //Log.e("INFO", "Result cancelled");
            }
        }
    }

    //creates a new Intent that allows the MainActivity to go to SecondActivity.java
    public void startSecondActivity() {
        Intent intent = new Intent(this, SecondActivity.class);
        startActivityForResult(intent, 0);
    }

    //opens the dialer function in Android
    public void openDialer()
    {
        //gets the number that is displayed on the MainActivity screen
        String numInput = welcomeTxt.getText().toString();

        //if the number is in valid then user should be informed that the number that has been entered
        // is invalid and includes the number as well and should break out of this function
        if(numberValid != -1)
        {
            Toast.makeText(this, "Invalid Number: " + numInput, Toast.LENGTH_LONG).show();
            return;
        }

        Uri x = Uri.parse("tel:" + numInput); //<-sets up the format of the phone number

        Intent intent = new Intent(Intent.ACTION_DIAL, x); //creates new Intent for going to the dialer app on the device
        try
        {
            //opens the phone app dial.
            startActivity(intent);
        }
        catch (SecurityException s)
        {
            // displays message if there is a problem
            Toast.makeText(this, s.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

}