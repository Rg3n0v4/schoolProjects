package com.example.project_2;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;

public class carImageActivity extends AppCompatActivity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // gets the intent from MainActivity to use for this activity
        final Intent intent = getIntent();

        //creates an image view that will be used for the image of the car
        ImageView imageView = new ImageView(getApplicationContext());

        // gets the image from MainActivity
        imageView.setImageResource(intent.getIntExtra("POS", 0));

        //add the link to car manufacturer onto the ImageView itself
        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent openLink = new Intent(Intent.ACTION_VIEW); //opens link in another browser
                openLink.setData(Uri.parse(intent.getStringExtra("LINK"))); //grabs the link from carSites in MainActivity
                startActivity(openLink);
            }
        });

        setContentView(imageView); //changes what's being shown in the UI
    }
}
