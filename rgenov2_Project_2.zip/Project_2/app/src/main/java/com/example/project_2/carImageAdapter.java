package com.example.project_2;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;

public class carImageAdapter extends BaseAdapter {

    private Context context;       // this is needed for transitioning into ImageView and TextView
    private List<Integer> carIds;  // list of integers that hold the car ids
    private List<String> carNames; // list of strings that hold the car names
    private LayoutInflater l_inflater; //LayoutInflater for once ImageView and TextView are done and need to go into context

    //Constructor that takes in the context, list of the car ids, and list of car names
    public carImageAdapter(Context c, List<Integer> ids, List<String> names) {
        context = c;
        this.carIds = ids;
        this.carNames = names;
        this.l_inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    // Return the number of items in the Adapter
    @Override
    public int getCount() {
        return carIds.size();
    }

    // Return the data item at position
    @Override
    public Object getItem(int position) {
        return carIds.get(position);
    }

    // Will get called to provide the ID that
    // is passed to OnItemClickListener.onItemClick()
    @Override
    public long getItemId(int position) {
        return carIds.get(position);
    }

    // return the "new" view that contains the enlarged image of the car
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        //checks if the convertView is recycled
        if (convertView == null) {
            convertView = l_inflater.inflate(R.layout.activity_row_layout, parent, false);
        }
        ImageView imageView = convertView.findViewById(R.id.rowImage);
        TextView textView = convertView.findViewById(R.id.rowText);

        imageView.setImageResource(carIds.get(position));
        textView.setText(carNames.get(position));

        return convertView;
    }

}
