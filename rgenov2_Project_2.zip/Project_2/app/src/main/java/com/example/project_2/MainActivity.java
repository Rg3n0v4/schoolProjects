package com.example.project_2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.GridView;
import java.util.ArrayList;
import java.util.Arrays;

public class MainActivity extends AppCompatActivity {

    private GridView tnGrid; //GridView that will contain all of the ImageViews and TextViews to come

    //all of the information on all of the cars
    private ArrayList<Integer> carThumbnails = new ArrayList<Integer>(
            Arrays.asList(R.drawable.ffcar, R.drawable.ffcar2, R.drawable.ffcar3,
                    R.drawable.ffcar4, R.drawable.ffcar5, R.drawable.ffcar6));
    private ArrayList<String> carNames = new ArrayList<String>(
            Arrays.asList("1994 Toyota Supra Turbo", "1995 Mitsubishi Eclipse", "1989 Nissan Skyline",
                            "1970 Dodge Charger R/T", "1997 Mazda RX-7", "1971 Chevrolet Monte Carlo"));
    private ArrayList<String> carSites = new ArrayList<String>(
            Arrays.asList("https://www.toyota.com/","https://www.mitsubishicars.com/#filter-modal","https://www.nissanusa.com/",
                    "https://www.dodge.com/", "https://www.mazdausa.com/", "https://www.chevrolet.com/"));
    private ArrayList<String> carDealers = new ArrayList<String>(
            Arrays.asList("Toyota", "Mitsubishi", "Nissan",
                            "Dodge", "Mazda", "Chevrolet"));

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tnGrid = (GridView) findViewById(R.id.tnGrid);

        // Create a new ImageAdapter and set it as the Adapter for this GridView
        tnGrid.setAdapter(new carImageAdapter(this, carThumbnails, carNames));

        registerForContextMenu(tnGrid);

        // Set an setOnItemClickListener on the GridView
        tnGrid.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> parent, View v, int position, long id) {
                //creates an intent that is sent to carImageActivity
                Intent intent = new Intent(MainActivity.this, carImageActivity.class);

                intent.putExtra("POS", (int) id); //takes the id of the current picture selected
                intent.putExtra("LINK", carSites.get(position)); //gives the link to the selected car manufacturer website

                //start the carImageActivity
                startActivity(intent);
            }
        });
    }

    //creates the ContextMenu for the long click (long click is initialized to true in the xml file for this activity)
    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);
        menu.add(0, v.getId(), 0, "View The Entire Picture");
        menu.add(0, v.getId(), 0, "Show Car Manufacturer");
        menu.add(0, v.getId(), 0, "List of Dealers");
    }

    @Override
    public boolean onContextItemSelected(MenuItem item) {
        String itemText = (String) item.getTitle();
        AdapterView.AdapterContextMenuInfo mInfo = (AdapterView.AdapterContextMenuInfo) item.getMenuInfo();

        switch (itemText) {
            case "View The Entire Picture": //same as setOnClickListener for tnGrid
                //creates an intent that is sent to carImageActivity
                Intent intent = new Intent(MainActivity.this, carImageActivity.class);

                intent.putExtra("POS", carThumbnails.get(mInfo.position)); //takes the id of the current picture selected
                intent.putExtra("LINK", carSites.get(mInfo.position)); //gives the link to the selected car manufacturer website

                //start the carImageActivity
                startActivity(intent);
                return true;
            case "Show Car Manufacturer": //same as setOnClickListener for imageView in carImageActivity
                //creates an intent that opens a browser within the Android Emulator
                Intent openLink = new Intent(Intent.ACTION_VIEW);
                openLink.setData(Uri.parse(carSites.get(mInfo.position)));

                //starts the intent of opening the browser with the specified link
                startActivity(openLink);
                return true;
            case "List of Dealers": //opens carListActivity to show the car dealers with the specific car manufacturer
                //creates an intent that is sent to carListActivity
                Intent _intent = new Intent(MainActivity.this, carListActivity.class);
                _intent.putExtra("NAME", carDealers.get(mInfo.position));

                //start the carListActivity
                startActivity(_intent);
                return true;
            default:
                return false;
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        tnGrid = null; //"resets" the GridView since the screen is currently with the enlarged picture
    }

    //same as onCreate because tnGrid was set to null when it was paused
    @Override
    protected void onRestart() {
        super.onRestart();

        tnGrid = (GridView) findViewById(R.id.tnGrid);

        // Create a new ImageAdapter and set it as the Adapter for this GridView
        tnGrid.setAdapter(new carImageAdapter(this, carThumbnails, carNames));

        registerForContextMenu(tnGrid);

        // Set an setOnItemClickListener on the GridView
        tnGrid.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> parent, View v,
                                    int position, long id) {

                //Create an Intent to start the ImageViewActivity
                Intent intent = new Intent(MainActivity.this,
                        carImageActivity.class);

                // Add the ID of the thumbnail to display as an Intent Extra
                intent.putExtra("POS", (int) id);
                intent.putExtra("LINK", carSites.get(position));

                // Start the ImageViewActivity
                startActivity(intent);
            }
        });
    }

}