package com.example.project_2;

import android.app.ListActivity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.ArrayAdapter;

public class carListActivity extends ListActivity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // gets the intent from MainActivity to use for this activity
        final Intent intent = getIntent();

        //the whole list of if/else if statements are all grabbing from names of the car manufacturers in MainActivity
        // this is done in the 3rd option in the context menu. All the addresses of the car dealers based on the manufacturer
        //is in strings.xml

        if(intent.getStringExtra("NAME").equals("Toyota")){
            setListAdapter(new ArrayAdapter<String>(this, R.layout.activity_car_manu_list,
                    getResources().getStringArray(R.array.Toyota)));
        }
        else if(intent.getStringExtra("NAME").equals("Mitsubishi")) {
            setListAdapter(new ArrayAdapter<String>(this, R.layout.activity_car_manu_list,
                    getResources().getStringArray(R.array.Mitsubishi)));
        }
        else if(intent.getStringExtra("NAME").equals("Nissan")) {
            setListAdapter(new ArrayAdapter<String>(this, R.layout.activity_car_manu_list,
                    getResources().getStringArray(R.array.Nissan)));
        }
        else if(intent.getStringExtra("NAME").equals("Dodge")) {
            setListAdapter(new ArrayAdapter<String>(this, R.layout.activity_car_manu_list,
                    getResources().getStringArray(R.array.Dodge)));
        }
        else if(intent.getStringExtra("NAME").equals("Mazda")) {
            setListAdapter(new ArrayAdapter<String>(this, R.layout.activity_car_manu_list,
                    getResources().getStringArray(R.array.Mazda)));
        }
        else if(intent.getStringExtra("NAME").equals("Chevrolet")) {
            setListAdapter(new ArrayAdapter<String>(this, R.layout.activity_car_manu_list,
                    getResources().getStringArray(R.array.Chevrolet)));
        }
    }

}
