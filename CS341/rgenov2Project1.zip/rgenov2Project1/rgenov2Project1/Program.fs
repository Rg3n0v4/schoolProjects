﻿
open ListLib
open Project01
open Project01_01
open Project01_02
open Project01_03
open Project01_04
open Project01_05
open Project01_06
open Project01_07
open Project01_08
open Project01_09
open Project01_10
open Project01_11
open Project01_12
open Project01_13
open Project01_14
open Project01_15
open Project01_16

[<EntryPoint>]
let main argv = 
    ignore (Project01_01.main [])
    ignore (Project01_02.main [])
    ignore (Project01_03.main [])
    ignore (Project01_04.main [])
    ignore (Project01_05.main [])
    ignore (Project01_06.main [])
    ignore (Project01_07.main [])
    ignore (Project01_08.main [])
    ignore (Project01_09.main [])
    //ignore (Project01_10.main [])
    ignore (Project01_11.main [])
    ignore (Project01_12.main [])
    ignore (Project01_13.main [])
    ignore (Project01_14.main [])
    ignore (Project01_15.main [])
    ignore (Project01_16.main [])
    0 // return an integer exit code