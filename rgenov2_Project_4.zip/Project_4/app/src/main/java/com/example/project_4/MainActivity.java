package com.example.project_4;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.pm.ActivityInfo;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;

import org.w3c.dom.Text;

import java.util.ArrayList;
import java.util.Random;

public class MainActivity extends AppCompatActivity {

    //LinearLayout for dynamically adding in TextViews in the ScrollView
    public LinearLayout player1Actions;
    public LinearLayout player2Actions;

    //player 1 left to right
    //player 1's strategy for winning is getting the correct digits from the left correct before the digits on the right
    private LinearLayout player1LinearLayout;
    public ArrayList<Integer> player1Num = new ArrayList<Integer>(); //player 1's chosen number
    private ThreadPlayer p1Thread;

    //player 2 right to left
    //player 2's strategy for winning is getting the correct digits from the right correct before the digits on the left
    private LinearLayout player2LinearLayout;
    public ArrayList<Integer>  player2Num = new ArrayList<Integer>(); //player 2's chosen number
    private ThreadPlayer p2Thread;

    public Handler mainHandler = new Handler(){public void handleMessage(Message msg) {
        Log.i("INFO", "MAINHANDLER");

            int what = msg.what;
            switch (what) {
                case 1:
                    updateLayout(1);
                    break;
                case 2:
                    updateLayout(2);
                    break;
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setRequestedOrientation (ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE); //locks app to be in landscape
        setContentView(R.layout.activity_main);

        Toolbar guessFourAB = (Toolbar) findViewById(R.id.guessFourActionBar); //ActionBar creation
        setSupportActionBar(guessFourAB);

        player1LinearLayout = (LinearLayout) findViewById(R.id.player1_fragment_container);
        player2LinearLayout = (LinearLayout) findViewById(R.id.player2_fragment_container);
        player1Actions = new LinearLayout(this);
        player2Actions = new LinearLayout(this);

        player1Actions.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT));
        player1Actions.setOrientation(LinearLayout.VERTICAL);
        player2Actions.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT));
        player2Actions.setOrientation(LinearLayout.VERTICAL);

        ScrollView p1ScrollView = (ScrollView) findViewById(R.id.player1Scroll);
        p1ScrollView.addView(player1Actions);

        ScrollView p2ScrollView = (ScrollView) findViewById(R.id.player2Scroll);
        p2ScrollView.addView(player2Actions);

        p1Thread = new ThreadPlayer(1);
        p2Thread = new ThreadPlayer(2);

        p1Thread.start();
        p2Thread.start();

    }

    // Create ActionBar Menu
    @Override
    public boolean onCreateOptionsMenu(Menu menu) { //android calls this function automatically
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.actionbar_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item)
    {
        String itemText = (String) item.getTitle();
        switch(itemText){
            case "START GAME": //for starting the game
                Log.i("TEST", "OP 1 works");

                TextView status = (TextView) findViewById(R.id.gameStatus);
                status.setText("Game has started");

                p1Thread.loopCounter = 0;
                p2Thread.loopCounter = 0;
                p1Thread.guessCounter = 0;
                p2Thread.guessCounter = 0;

                p1Thread.finished = false;
                p2Thread.finished = false;

                p1Thread.oppHandler = p2Thread.pHandle;
                p1Thread.mainHandlerThread = mainHandler;

                p2Thread.oppHandler = p1Thread.pHandle;
                p2Thread.mainHandlerThread = mainHandler;

                p1Thread.pHandle.post(new playerRunnable(false));
                p2Thread.pHandle.post(new playerRunnable(true));

                p1Thread.pHandle.sendEmptyMessage(2319);
                p2Thread.pHandle.sendEmptyMessage(2319);

                return true;
            case "STOP GAME": //for stopping or restarting the game
                Log.i("TEST", "OP 2 works");

                TextView _status = (TextView) findViewById(R.id.gameStatus);
                _status.setText("Previous game has ended a new game has started");

                p1Thread.loopCounter = 0;
                p2Thread.loopCounter = 0;
                p1Thread.finished = false;
                p2Thread.finished = false;

                p1Thread.oppHandler = p2Thread.pHandle;
                p1Thread.mainHandlerThread = mainHandler;

                p2Thread.oppHandler = p1Thread.pHandle;
                p2Thread.mainHandlerThread = mainHandler;

                p1Thread.pHandle.post(new playerRunnable(false));
                p2Thread.pHandle.post(new playerRunnable(true));

                p1Thread.guessCounter = 0;
                p2Thread.guessCounter = 0;

                p1Thread.pHandle.sendEmptyMessage(2319);
                p2Thread.pHandle.sendEmptyMessage(2319);

                return true;
            default:
                return false;
        }
    }

    public class playerRunnable implements Runnable{

        Boolean player; //false = player 1 | true = player 2

        public playerRunnable(Boolean whichPlayer)
        {
            player = whichPlayer;
        }

        public ArrayList<Integer> createNum()
        {
            ArrayList<Integer> num = new ArrayList<Integer>();

            while(num.size() != 4)//while there hasn't been a repeated digit yet and there hasn't been a full list of 4 numbers yet
            {
                Random r_digit = new Random();
                int digit = r_digit.nextInt(10); //picks from 0-9
                if(!num.contains(digit)) //if the digit isn't a part of the ArrayList yet then add it on
                {
                    num.add(digit);
                }
            }

            return num; //return random set of integers
        }

        @Override
        public void run() {
            final ArrayList<Integer> r_num = createNum();
            if (player == false)
            {
                player1Num = r_num;
                p1Thread.playerNum = r_num;
                Log.i("TEST", "EAFAFDFAD");
            }
            else
            {
                player2Num = r_num;
                p2Thread.playerNum = r_num;
                Log.i("TEST", "asdfasdfasdfasdfasdf");
            }

            //UI thread
//            for(int i = 0; i < player1Num.size(); i++)
//            {
//                Log.i("TEST PRINT OUT PLAYER 1", "@" + i + ": " + player1Num.get(i));
//            }
            TextView p1Txt =  (TextView) findViewById(R.id.player1NumTxt);
            String p1GuessString = player1Num.toString().replace(",","").replace(" ","").replace("[","").replace("]","");
            p1Txt.setText("Player 1: " + p1GuessString);

//            for(int i = 0; i < player2Num.size(); i++)
//            {
//                Log.i("TEST PRINT OUT PLAYER 2", "@" + i + ": " + player2Num.get(i));
//            }
            TextView p2Txt =  (TextView) findViewById(R.id.player2NumTxt);
            String p2GuessString = player2Num.toString().replace(",","").replace(" ","").replace("[","").replace("]","");
            p2Txt.setText("Player 2: " + p2GuessString);
            Log.i("INFO", "run Guess #" +p1Thread.guessCounter + "= Correct places: " + p1Thread.numOfCorrectPlace + " Correct digits: " + p1Thread.numberOfCorrectDigit);
            Log.i("INFO", " run Guess #" + p2Thread.guessCounter + "= Correct places: " + p2Thread.numOfCorrectPlace + " Correct digits: " + p2Thread.numberOfCorrectDigit);
        }
    }

    public void updateLayout(int playerNum)
    {
        Log.i("INFO", "P1 updateLayout Guess #" +p1Thread.guessCounter + "= Correct places: " + p1Thread.numOfCorrectPlace + " Correct digits: " + p1Thread.numberOfCorrectDigit);
        Log.i("INFO", "P2 updateLayout Guess #" + p2Thread.guessCounter + "= Correct places: " + p2Thread.numOfCorrectPlace + " Correct digits: " + p2Thread.numberOfCorrectDigit);

        TextView status = (TextView) findViewById(R.id.gameStatus);
        if(p1Thread.guessCounter != 20 || p2Thread.guessCounter != 20)
        {
            status.setText("Game in progress...");
        }
        else
        {
            status.setText("Game has ended");
        }

        if(playerNum == 1)
        {
            TextView newUpdate = new TextView(this);
            newUpdate.setText("Guess #" +p1Thread.guessCounter + "= Correct places: " + p1Thread.numOfCorrectPlace + " Correct digits: " + p1Thread.numberOfCorrectDigit);
            player1Actions.addView(newUpdate);
        }
        if(playerNum == 2)
        {
            TextView newUpdate = new TextView(this);
            newUpdate.setText("Guess #" + p2Thread.guessCounter + "= Correct places: " + p2Thread.numOfCorrectPlace + " Correct digits: " + p2Thread.numberOfCorrectDigit);
            player2Actions.addView(newUpdate);
        }
    }
}