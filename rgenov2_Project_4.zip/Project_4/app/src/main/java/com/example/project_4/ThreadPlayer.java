package com.example.project_4;

import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.util.Log;

import androidx.annotation.NonNull;

import java.util.ArrayList;
import java.util.Random;

public class ThreadPlayer extends Thread {

    public Handler pHandle; //player's Handler
    public Handler oppHandler; //opponent's Handler
    public int pNum; //player's number (either 1 or 2)
    public ArrayList<Integer> pGuess = new ArrayList<Integer>(4);
    public ArrayList<Integer> playerNum = new ArrayList<Integer>(4);
    public int numOfCorrectPlace = 0; //counts the number of correct places and correct numbers that the computer has guesseed
    public int numberOfCorrectDigit = 0; //counts the number of correct digits REGARDLESS of placement
    public int guessCounter = 0;
    public Handler mainHandlerThread;
    public int loopCounter = 0;
    public Boolean finished = false;

    //Constructor
    public ThreadPlayer(int num){
        pNum = num;
    }

    public ArrayList<Integer> makeGuess(){
        ArrayList<Integer> guess = new ArrayList<Integer>();

        while(guess.size() != 4)//while there hasn't been a repeated digit yet and there hasn't been a full list of 4 numbers yet
        {
            Random r_digit = new Random();
            int digit = r_digit.nextInt(10); //picks from 0-9
                if(!guess.contains(digit))
                {
                    guess.add(digit);
                }
        }

        return guess;
    }

    @Override
    public void run() {
        Looper.prepare();
        pHandle = new Handler(){
            @Override
            public void handleMessage(Message msg) {
                int msgWhat = msg.what;
                switch(msgWhat){
                    case 2319: //starts the guessing for the player
                        if(loopCounter < 20 && !finished)
                        {
                            loopCounter++;
                            pGuess = makeGuess();
                            //Log.i("INFO", pGuess.toString());
                            String stringV_pGuess = pGuess.toString().replace(",", "").replace(" ", "").replace("[", "").replace("]", "");
                            Log.i("INFO", "pNum: " + pNum + " guess: " + stringV_pGuess);
                            Message nextCaseMsg = new Message();
                            nextCaseMsg.what = 5432;
                            nextCaseMsg.arg1 = Integer.parseInt(stringV_pGuess);
                            oppHandler.sendMessage(nextCaseMsg);
                            //Log.i("INFO", "AJKLAJSLJLKFLSDFJKLJFDSKLFJL");
                        }
                        break;
                    case 5432: //sends it back to opponent handler and loops back around
                        //Log.i("INFO", "1233453465234");

                        numberOfCorrectDigit = 0;
                        numOfCorrectPlace = 0;

                        int pGuess_num = msg.arg1;
                        String pGuess_toString = Integer.toString(msg.arg1).replace(",","").replace(" ","").replace("[","").replace("]","");

                        if(pGuess_num/1000 <= 0)
                        {
                            pGuess_toString = "0" + pGuess_toString;
                        }
                        Log.i("INFO", "pNum: " + pNum + " guess: "+ pGuess_toString);

                        for (int i = 0; i < pGuess_toString.length(); i++) {
                            if (((int) pGuess_toString.charAt(i)) == ((int) playerNum.get(i).toString().charAt(0)))
                            {
                                numOfCorrectPlace++;
                            }
                            if(playerNum.contains(Character.getNumericValue(pGuess_toString.charAt(i))))
                            {
                                numberOfCorrectDigit++;
                            }
                        }

                        guessCounter++;

                        Message setUpGuess = new Message();
                        if(pNum == 1)
                        {
                            setUpGuess.what = 1;
                        }
                        else
                        {
                            setUpGuess.what = 2;
                        }

                        //Log.i("INFO", "MAINHANDLERTHREAD IN THREAD WILL GO TO: " + setUpGuess.what);
                        mainHandlerThread.sendMessage(setUpGuess);
                        if(pGuess_toString.equals(playerNum.toString().replace(",","").replace(" ","").replace("[","").replace("]","")))
                        {
                            oppHandler.sendEmptyMessage(5678);
                            finished = true;
                        }
                        else
                        {
                            oppHandler.sendEmptyMessage(2319);
                        }
                        try{
                            Thread.sleep(2000);
                        }catch(InterruptedException e)
                        {
                            e.printStackTrace();
                        }
                        break;
                    case 5678:
                        mainHandlerThread.removeCallbacksAndMessages(null);
                        break;
                }

            }
        };
        Looper.loop();
    }
}
