import java.util.*;

public class GenericPractice<T, D>
{
    ArrayList<T> list;
    D data;

    GenericPractice(D data)
    {
        list = new ArrayList<T>();
        this.data = data;
    }
    void storeValue(T val)
    {
        list.add(val);
    }

    void changeValue(T val, int index)
    {
        list.set(index, val);
    }

    void print()
    {
        if(list.isEmpty())
        {
            System.out.println("empty list");
        }
        else
        {
            for(int i = 0; i < list.size(); i++)
            {
                System.out.println(list.get(i));
            }
        }
    }

    public static void main(String[] args)
    {
        GenericPractice<Integer, >
    }
}
