
public class ChooseYourOwnHomework {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Person hero = new Hero();
		hero.showcase(true);

		Person villain = new Villain();
		villain.showcase(true);

	}

}
